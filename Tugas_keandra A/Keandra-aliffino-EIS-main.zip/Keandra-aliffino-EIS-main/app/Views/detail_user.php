<?= $this->extend('layout'); ?>
<?= $this->section('content'); ?>

<h2>Detail User</h2>

<div class="card">
    <div class="card-body">
        <h5 class="card-title"><?= $user['name'] ?></h5>
        <p><strong>Email:</strong> <?= $user['email'] ?></p>
        <p><strong>Gender:</strong> <?= $user['gender'] ?></p>
        <p><strong>Hobbies:</strong> 
            <?php 
                $hobbies = json_decode($user['hobbies'], true);
                echo is_array($hobbies) ? implode(', ', $hobbies) : '-';
            ?>
        </p>
        <p><strong>Country:</strong> <?= $user['country'] ?></p>
        <p><strong>Status:</strong> <?= $user['status'] ? 'Aktif' : 'Tidak Aktif' ?></p>

        <a href="<?= base_url('user') ?>" class="btn btn-secondary">Kembali</a>
    </div>
</div>

<?= $this->endSection(); ?>
